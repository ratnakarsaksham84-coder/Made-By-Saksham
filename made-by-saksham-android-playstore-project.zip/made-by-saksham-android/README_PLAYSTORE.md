# Made by Saksham — Android/Play Store build project

Target: Google Play, Android 16 / API 36
Application ID: com.madebysaksham.app
Version: 1.0.0 (versionCode 1)

## Build AAB
1. Open this folder in Android Studio.
2. Let Gradle sync/download Android Gradle Plugin 8.13.0.
3. Build > Generate Signed App Bundle > Android App Bundle.
4. Create/select a release keystore and keep it backed up.
5. Upload the generated .aab to Play Console.

This project wraps the offline HTML/JS app into a native Android WebView. No network permission is requested.

IMPORTANT: Before production publishing, test on real devices and complete Google Play developer-account requirements (including any required closed testing/review for a new personal account).
